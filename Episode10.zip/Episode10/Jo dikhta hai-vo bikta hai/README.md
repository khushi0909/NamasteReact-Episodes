#Namaste React 




# Parcel 
-Dev Build
-Local Server
-HMR - Hot Module Replacement 
-File Watching Algorithms -written in c++
-caching -Faster builds
-Image Optimization
-Minification
-Bundling 
-Compress
-Consistent Hashing 
-Code spilitting 
-Differential Bundling -support old browser 
-Diagnostic 
-Error Handling 
-HTTPs
-Tree Shaking -remove unused code 
-Different dev and prod bundles

#Namaste Food

Header 
        -logo
        -Nav Items 
Body
        -Searc
        -RestaurantContainer
            -img
            -Name of Res,star Rating ,cuisine,delivery time 
Footer
        -copyright
        -Links
        -Address
        -contact


        # Two Types of Export and Import 

        -Default Export/Import
        export default jjjj

        export default Component;
        import Component from "path";


        -Named Export/Import

        export const Component;
        import {Component} from "path"



        #React Hooks
        (Normal JS utility Functions )
        -useState()- super powerful State Varables in React 
        -useEffect()


        when we were using the filter method without hook ,it was giving us the result in consolelog but was not updating the ui ,but if we use useStat and set method of it ,it updates the ui also,so this is due to state variable when we were using normal variable it was not updating 

        whenever state variable changes react will rerender my component 




######


    // const [resData] = useState();  //this is same as let resData

    // const [resData , setResData] = useState(resDataa) is same as 

    // const arr =useState(resDataa)
    // const [resData , setResData] = arr


    //const resData = arr[0];
    // const setResData = arr[1];
