import React from "react"

const Grocery = () =>{

    return <h1>Our grocery online store ,and we have a lot of child components inside this web page</h1>
}

export default Grocery